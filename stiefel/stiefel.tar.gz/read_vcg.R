#vcg  <- read.table("tmp.csv")
vcg  <- read.table("vcg.csv")

tmp <- matrix(0,3,2);
S <- matrix(0,3,2);
X <- list();

for(i in 1:dim(vcg)[1]) {
  tmp[,1] <- t(vcg[i,1:3]);
  tmp[,2] <- t(vcg[i,4:6]);
  X[[i]] <- tmp;
  S     <- S + tmp;
}
num_obs <- length(X);
