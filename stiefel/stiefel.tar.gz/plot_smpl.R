pl = 2;
if(pl == 1) {
  pdf("hmc_plot.pdf")
  h <- read.table("res_hmc")

  plot(h[,3], type="o", pch=23, lty=3, col="blue",ylim = c(0,4), xaxt = 'n', yaxt = 'n', ann = FALSE, asp = .81, lwd = 7)
  lines(h[,1], type="o", pch=21, lty=1, col="red", lwd = 7)
  lines(h[,2], type="o", pch=22, lty=2, col="green", lwd = 7)
  lines(h[,4], type="o", pch=24, lty=4, col="brown", lwd = 7)

  axis(1, at=1:4, lab=c("0.1","0.3","0.5","random"),cex.axis = 2)
  axis(2, at=0:4, lab=c("0","1","2","3","4"),cex.axis = 2)

  title(xlab="Leapfrog step size", col.lab=rgb(0,0.0,0), cex.lab = 2)
  title(ylab="Effective samples per second", col.lab=rgb(0,0.0,0), cex.lab = 2)
# legend(.6,4,c("1 step", "3 steps", "5 steps", "10 steps"), cex=3, col=c("red","green", "blue", "brown"), pch=21:24, lty=1:4); 
  dev.off();
} else {

  pdf("mh_plot.pdf")
  h <- read.table("res_mh")
  h <- t(h);
  plot(h[,1], type="o", pch=21, lty=1, col="blue", ylim = c(0,0.71), xaxt = 'n', yaxt = 'n', ann = FALSE, lwd = 7)
  lines(h[,2], type="o", pch=22, lty=2, col="red", lwd = 7)
  axis(1, at=1:6, lab=c("0.1","0.3","0.5","1","1.5","2"),cex.axis = 2)
  axis(2, at=seq(0,.7,.1), lab=c("0","0.1","0.2","0.3","0.4","0.5","0.6","0.7"),cex.axis = 2)

  title(xlab="Variance of Metropolis proposals", col.lab=rgb(0,0.0,0), cex.lab = 2)
  title(ylab="Effective samples per second", col.lab=rgb(0,0.0,0), cex.lab = 2)
# legend(1,0.7,c("Exchange sampler", "Latent history sampler"), cex=1.3, col=c("blue","red"), pch=21:22, lty=1:2); 
  dev.off();
}
