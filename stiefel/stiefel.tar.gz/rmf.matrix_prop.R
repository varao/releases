rmf.matrix_prop <-
function(G, kap)
{
  lr  <- 0;
  if(dim(kap)[2]==1) { X<-rmf.vector(G*kap) }
  if(dim(kap)[2]>1)
  {

    #simulate from the matrix mf "proposal" distribution described in Hoff(2009)
    #assumes ML is parametrized by an orthogonal matrix
    H <- G %*% kap
    m <- dim(H)[1] ; R<-dim(H)[2]

    proj_vec <- matrix(0,R,1);

    xn    <- sqrt(sum((H[,1]^2)))
    lr    <- xn + log(besselI(xn, .5*(m-1-1),expon.scaled=TRUE))- .5*(m-1-1)*log(xn);

    U     <- matrix(0,m,R)
    U[,1] <- rmf.vector(H[,1])
    proj_vec[1] <- xn/kap[1,1];

    for(j in seq(2,R,length=R-1))
    {
      N      <-NullC(U[,seq(1,j-1,length=j-1)])
      h_proj <-t(N)%*%H[,j];
      x      <-rmf.vector(h_proj)
      xn     <- sqrt(sum(h_proj^2));
      lr   <- lr + xn + log(besselI(xn, .5*(m-j-1),expon.scaled=TRUE))- .5*(m-j-1)*log(xn);
      U[,j]<- N%*%x
      proj_vec[j] <- xn/kap[j,j];
    }
#     print("B")
#     print(lr)

  }
  return(list(U, lr, proj_vec));
}


rmf.log_D <-
function(H, X = FALSE)
{
  #get denominator (upto constant) of probability of a matrix simulated from the matrix mf "proposal" distribution described in Hoff(2009)
  #assumes ML is parametrized by an orthogonal matrix

  m<-dim(H)[1] ; R<-dim(H)[2]

  if(identical(X, FALSE)) {
    xn    <- sqrt(sum((H[,1]^2)))
    lr    <- xn + log(besselI(xn, .5*(m-1-1),expon.scaled=TRUE))- .5*(m-1-1)*log(xn);

    for(j in seq(2,R,length=R-1))
    {
      xn  <- sqrt(sum( (H[,j]^2)))
      lbr <- xn + log(besselI(xn, .5*(m-j-1),expon.scaled=TRUE))- .5*(m-j-1)*log(xn);
      lr  <- lr+ lbr;   # + lgamma(0.5*(m-j+1)) + .5*(m-j-1)*log(2)
    }
  }
  else {
    xn    <- sqrt(sum((H[,1]^2)))
    lr    <- xn + log(besselI(xn, .5*(m-1-1),expon.scaled=TRUE))- .5*(m-1-1)*log(xn);

    for(j in seq(2,R,length=R-1))
    {
      N   <-NullC(X[,seq(1,j-1,length=j-1)])

      xn  <- sqrt(sum( (t(N)%*%H[,j])^2))
      lbr <- xn + log(besselI(xn, .5*(m-j-1),expon.scaled=TRUE))- .5*(m-j-1)*log(xn);

      lr<- lr+ lbr;   # + lgamma(0.5*(m-j+1)) + .5*(m-j-1)*log(2)
    }
  }

  return(lr);
}

rmf.prod_bess <-                             # Same as log_D, but don't need G
function(kap,  m, R, proj = FALSE) {
  if(identical(proj, FALSE)) {
    Z <- 0;
    for(j in 1:R) {
      xn <- kap[j,j];
      Z <- Z + xn + log(besselI(xn, .5*(m-j-1),expon.scaled=TRUE))- .5*(m-j-1)*log(xn);
    }
  }
  else {
    Z <- 0;
    for(j in 1:R) {
      xn <- proj[j] * kap[j,j];
      Z <- Z + xn + log(besselI(xn, .5*(m-j-1),expon.scaled=TRUE))- .5*(m-j-1)*log(xn);
    }
  }
  return(Z);
}


rmf.log_joint <- 
function(S, H, kap, proj, num_obs, num_rej, m, R) {
  G= H %*% kap;
  D_bound  <- rmf.log_D(G);
  
  Z <- 0;
  if(num_rej > 0) {
    for( p in 1:num_rej ) {
      D_curr <- rmf.prod_bess(kap, m,  R, proj[[p]]); 
      Z      <- Z + log(exp(D_bound - D_curr) - 1);
    }
  }
  Z <- Z + sum(diag( G %*% t(S) )) - (num_obs + num_rej) * D_bound - sum(kap);
}


rmf.grad <- 
function(S_vec, kap, proj, num_obs, num_rej, m, R, get_Z = FALSE) {

  Z      <- 0;
  grad   <- array(0,R);
  grad_l <- array(0,R);

  bess   <- matrix(0,R,2);

  D_bound <- rmf.prod_bess(kap, m, R)  # Same as log_D, but don't need G

  for(i in 1:R) {
      bess[i,1] <- besselI(kap[i,i], .5*(m-i-1),expon.scaled=TRUE)
      bess[i,2] <- besselI(kap[i,i], .5*(m-i+1),expon.scaled=TRUE)
  }

  if(num_rej > 0) {
    for(i in 1:num_rej) {
      prod = 0;

      for(j in 1:R) {
        b1        <- besselI(proj[[i]][j]*kap[j,j], .5*(m-j-1),expon.scaled=TRUE);
        b2        <- besselI(proj[[i]][j]*kap[j,j], .5*(m-j+1),expon.scaled=TRUE)
        grad_l[j] <- bess[j,2]/bess[j,1] -  proj[[i]][j]*b2/b1;
        prod      <- prod + kap[j,j]*proj[[i]][j] + log(b1) - 0.5*(m-j-1)*log(kap[j,j]*proj[[i]][j]);
      }
#     if(abs(prod - rmf.prod_bess(kap,m,R,proj[[i]])) > 0.01) {
#       print(prod);
#       print(rmf.prod_bess(kap,m,R,proj[[i]])) 
#       stop("WTH??");
#     }
      denom <- (1 - exp(prod-D_bound));
      for(j in 1:R) {
        grad[j] <- grad[j] + grad_l[j]/denom;
      }
      if(isTRUE(get_Z))
        Z <- Z + (D_bound - prod) + log(denom);

    }
  }
  grad <- grad - (num_obs + num_rej)*bess[,2]/bess[,1];
  kap_rate <- 1;
  grad <- S_vec + grad -1/kap_rate;

  if(isTRUE(get_Z)) {
#    Z <- Z - (num_obs + num_rej) * D_bound - sum(diag(kap)) + sum(S_vec * diag(kap));
    return(list(grad,Z));
  }
  else
    return(grad);   # Include the rate-1 exponential prior
}


rmf.get_proj <-
function(G, X, m, R) {
  if(dim(kap)[2]==1) { #X<-rmf.vector(G) 
  }
  if(dim(kap)[2]>1)
  {

    #simulate from the matrix mf "proposal" distribution described in Hoff(2009)
    #assumes ML is parametrized by an orthogonal matrix

    proj_vec <- matrix(0,R,1);

    proj_vec[1] <- sqrt(sum((G[,1]^2)));

    for(j in seq(2,R,length=R-1))
    {
      N      <-NullC(X[,seq(1,j-1,length=j-1)])
      prj    <- t(N)%*%G[,j]
      proj_vec[j] <- sqrt(sum(prj^2));
    }
  }
  return(proj_vec);
}


rmf.get_lik <-
function(kap, G, X, Y, num_rej) {
  
  m <- dim(G)[1] ; R<-dim(G)[2]

  proj_vec <- list();
  for(i in seq_len(num_rej)) {
    proj_vec[[i]]   <- rmf.get_proj(G, Y[[i]], m, R);
  }
  return(rmf.log_joint(X, G, kap, proj_vec, 1, num_rej, m, R));
}


rmf.get_Z_approx <-
function(kap, dims) {
  df    <- (dims[1] - dims[2]);
  Z     <- sum(kap);
  Z     <- Z - 0.5 * df * log(kap[1,1]);
  for(i in seq_len(dims[2]-1)+1) {
    Z   <- Z - 0.5 * df * log(kap[i,i]);
    for(j in seq_len(i-1))
      Z   <- Z - 0.5*log(kap[i,i] + kap[j,j]);
  }
  return(Z)
}

