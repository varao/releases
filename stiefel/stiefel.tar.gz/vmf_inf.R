# Vinayak Rao
# R code for inference on the stiefel manifold
#  Data augmentation for models based on rejection sampling 
#  Rao, V.A., Lin, L. and Dunson, D.B. (2014) 

library("rstiefel");

# Notation here is slightly different from the paper. In particular,
# Paper -> Code
# G -> H, F_1 -> F, F -> G


vmf_approx <-
function(num_iter, F, kap, H, num_obs, S, scale=0.5, kap_mn = 1)
{
#  print("Running approximate sampler!")
  # Exchange sampler
  Y        <- list();
  kap_post <- list();
  H_post   <- list();

  dims = dim(S);
  df <- (dims[1] - dims[2]);
  acc_cnt = 0;
  Z <- rmf.get_Z_approx(kap,dims);

  for(iter in 1:num_iter ) {
    if (iter %% 100 == 0) {
      print(iter);
      print(acc_cnt);
    }

    kap_new <- kap + scale*diag(rnorm(dims[2]));

    if(min(kap_new) >= 0) {
      Z_new <- rmf.get_Z_approx(kap_new,dims);

      log_acc = sum(diag( (kap_new - kap) %*% t(H) %*% S )) + num_obs*(Z - Z_new);
      log_pr = sum(-kap_new + kap)/kap_mn;    # exponential prior
#      cat(log_pr + log_acc, " ", Z_new, " ", Z, " ", kap_new, " ", kap, "\n")
      if( log(runif(1)) < (log_pr + log_acc)) {
        kap = kap_new;
        Z   = Z_new;
        acc_cnt = acc_cnt + 1;
      }
    }
    H <- rmf.matrix(S %*% kap + F);

    kap_post[[iter]] <- kap;
    H_post[[iter]]   <- H;
  }
  return(list(kap_post, H_post, acc_cnt));
}


vmf_xchg <-
function(num_iter, F, kap, H, num_obs, S, scale=0.5, kap_mn = 1)
{
#  print("Running exchange sampler!")
  # Exchange sampler
  Y        <- list();
  kap_post <- list();
  H_post   <- list();

  dims = dim(S);
  acc_cnt = 0;
  for(iter in 1:num_iter ) {
    if (iter %% 100 == 0) {
      print(iter);
      print(acc_cnt);
    }

    kap_new <- kap + scale*diag(rnorm(dims[2]));

    pS = matrix(0,dims[1], dims[2]);

    if(min(kap_new) >= 0) {
      for( p in 1:num_obs ) {
        Y[[p]] <- rmf.matrix(H %*% kap_new);
        pS     <- pS + Y[[p]];
      }
      log_acc = sum(diag( H %*% (kap_new - kap) %*% t(S - pS) ));
      log_pr = sum(-kap_new + kap)/kap_mn;    # exponential prior
      if( log(runif(1)) < (log_pr + log_acc)) {
        kap = kap_new;
        acc_cnt = acc_cnt + 1;
      }
    }
    H <- rmf.matrix(S %*% kap + F);

    kap_post[[iter]] <- kap;
    H_post[[iter]]   <- H;
  }
  return(list(kap_post, H_post, acc_cnt));
}

vmf_xchg_approx <-
function(num_iter, F, kap, H, num_obs, S, scale=0.5, num_obs_true = num_obs)
{
  print("Running approximate exchange sampler!")
  # Exchange sampler
  Y        <- list();
  kap_post <- list();
  H_post   <- list();

  dims = dim(S);
  acc_cnt = 0;
  for(iter in 1:num_iter ) {
    if (iter %% 100 == 0) {
      print(iter);
      print(acc_cnt);
    }

    kap_new <- kap + scale*diag(rnorm(dims[2]));


    if(min(kap_new) >= 0) {
      for( p in 1:num_obs ) {
        Y[[p]] <- rmf.matrix(H %*% kap_new);
        pS     <- pS + Y[[p]];
      }
      log_acc = sum(diag( H %*% (kap_new - kap) %*% (t(S - pS)* num_obs_true/num_obs) ));
      log_pr = sum(-kap_new + kap)/10;    # exponential prior
      if( log(runif(1)) < (log_pr + log_acc )) {
        kap = kap_new;
        acc_cnt = acc_cnt + 1;
      }
    }
    H <- rmf.matrix(S %*% kap + F);

    kap_post[[iter]] <- kap;
    H_post[[iter]]   <- H;
  }
  return(list(kap_post, H_post, acc_cnt));
}



vmf_lat_hist <-
function(num_iter, F, kap, H, num_obs, S, X, scale=0.5)
{
  print("Running Lat. hist sampler!")
  # F is the prior on H

  dims     <- dim(S);
  Y        <- list();
  proj_vec <- list();
  kap_post <- list();
  H_post   <- list();

  acc_cnt = 0;


  for(iter in 1:num_iter ) {
    if (iter %% 100 == 0) {
      print(iter);
      print(acc_cnt);
    }
    G = H %*% kap;

    D_bound     <- rmf.log_D(G);
    pS          <- matrix(0,dims[1], dims[2]);
    num_rej     <- 0;
    Z           <- 0;
    Z_new       <- 0;
    for( p in 1:num_obs ) {
      acc     <- 0;
      loc_rej_cnt <- 0;
      while(!acc) {
        prop     <- rmf.matrix_prop(H, kap);   # Sample thinned events
        tmp_Y    <- prop[[1]];
        lr       <- prop[[2]];
        tmp_proj <- prop[[3]];
        acc           <- log(runif(1)) <  (lr - D_bound); 
        if(acc == FALSE) {
          num_rej               <- num_rej + 1;
          loc_rej_cnt           <- loc_rej_cnt + 1;
          Y[[num_rej]]          <- tmp_Y;
          proj_vec[[num_rej]]   <- tmp_proj;
          pS                    <- pS + tmp_Y;
          Z                     <- Z + log(exp(D_bound - lr) - 1);
        }
      }
    }

    for(lp in 1:2) {
    kap_new <- kap + scale*diag(rnorm(dims[2]));

    if(min(kap_new) >= 0) {

      G_new = H %*% kap_new;
      D_bound_new  <- rmf.log_D(G_new);
      
      if(num_rej > 0) {
        for( p in 1:num_rej ) {
#          D_curr = rmf.log_D(G_new, Y[[p]]);
          D_curr <- rmf.prod_bess(kap_new, dims[1],  dims[2], proj_vec[[p]]); 
          Z_new   <- Z_new + log(exp(D_bound_new - D_curr) - 1);
        }
      }

      log_acc <- Z_new - Z - (num_obs + num_rej) * (D_bound_new - D_bound);
      log_acc <- log_acc + sum(diag( (G_new - G) %*% t(S + pS) ));

      log_pr  <- sum(-kap_new + kap);    # exponential prior
      if( log(runif(1)) < (log_acc + log_pr)) {
        kap   <- kap_new;
        G     <- G_new;
        acc_cnt = acc_cnt + 1;
        Z     <- Z_new;
      }
    }
    }
    H <- rmf.matrix(S %*% kap + F);

    kap_post[[iter]] <- kap;
    H_post[[iter]]   <- H;
  }
  return(list(kap_post, H_post, acc_cnt));
}

vmf_hmc <-
function(num_iter, F, kap, H, num_obs, S, X, eps_ip  = 0.5, step = 5, kap_mean = 10)
{
  # F is the prior on H
#  print("Running HMC sampler!")

  kap_off   <- 0;
#  print("WARNING: CHECK THE OFFSET FOR kappa, CURRENTLY 0!!");

  dims     <- dim(S);
  Y        <- list();
  proj_vec <- list();
  kap_post <- list();
  H_post   <- list();
  S_vec    <- array(0,dims[2]);

  acc_cnt = 0;


  for(iter in 1:num_iter ) {
    if (iter %% 50 == 0) {
      print(iter);
      print(acc_cnt);
      print(kap);
    }
    G = H %*% kap;

    D_bound     <- rmf.log_D(G);
    pS          <- matrix(0,dims[1], dims[2]);
    num_rej     <- 0;
    Z           <- 0;
    Z_new       <- 0;
    for( p in 1:num_obs ) {
      acc     <- 0;
      loc_rej_cnt <- 0;
      while(!acc) {
        prop     <- rmf.matrix_prop(H, kap);   # Sample thinned events
        tmp_Y    <- prop[[1]];
        lr       <- prop[[2]];
        tmp_proj <- prop[[3]];
        acc           <- log(runif(1)) <  (lr - D_bound); 
        if(acc == FALSE) {
          num_rej               <- num_rej + 1;
          loc_rej_cnt           <- loc_rej_cnt + 1;
          Y[[num_rej]]          <- tmp_Y;
          proj_vec[[num_rej]]   <- tmp_proj;
          pS                    <- pS + tmp_Y;
          Z                     <- Z + log(exp(D_bound - lr) - 1);
        }
      }
#      print(Y);
    }

    for(j in 1:dims[2]) {
      S_vec[j] <- t(S[,j] + pS[,j]) %*% H[,j];
    }

    kap_old <- kap;
    mom_old <- rnorm(dims[2],0,1)  # independent standard normal variates
    mom     <- mom_old;

    diag(kap) = diag(kap) - kap_off;
    ################################
    # Run Hamiltonian dynamics
    if(eps_ip > 0) {
      eps <- eps_ip; }
    else
      eps <- runif(1);

    mom     <- mom + eps * rmf.grad(S_vec, kap+ kap_off * diag(dims[2]), proj_vec, num_obs, num_rej, dims[1], dims[2])/2;

    for (h in 1:step)
    {
      # Make a full step for the position
      kap <- kap + diag(eps * mom);
      ng  <- (diag(kap) < 0);
      diag(kap)[ng] <- -diag(kap)[ng];
      mom[ng] <- -mom[ng];

      # Make a full step for the momentum, except at end of trajectory
      if (h!=step)   
         mom <- mom + eps * rmf.grad(S_vec, kap + kap_off * diag(dims[2]), proj_vec, num_obs, num_rej, dims[1], dims[2]);
    }  
    gz      <- rmf.grad(S_vec, kap + kap_off * diag(dims[2]), proj_vec, num_obs, num_rej, dims[1], dims[2], TRUE);
    Z_new   <- gz[[2]]
    mom     <- mom + eps * gz[[1]]/2;
    kap_new <- kap + kap_off * diag(dims[2]);
    ################################

    G_new = H %*% kap_new;
    D_bound_new  <- rmf.log_D(G_new);
    
    log_acc <- Z_new - Z - (num_obs + num_rej) * (D_bound_new - D_bound);
    log_acc <- log_acc + sum(diag( (G_new - G) %*% t(S + pS) ));

    log_pr  <- sum(-kap_new + kap_old)/kap_mean;    # exponential prior
    log_pr  <- log_pr + sum(10*(log(diag(kap_new)) - log(diag(kap_old))));

    if( log(runif(1)) < (log_acc + log_pr - 0.5*(sum(mom^2) - sum(mom_old^2)))) {
      kap   <- kap_new;
      G     <- G_new;
      acc_cnt = acc_cnt + 1;
    }
    else {
      kap <- kap_old;
    }
    H <- rmf.matrix(S %*% kap + F);

    kap_post[[iter]] <- kap;
    H_post[[iter]]   <- H;
  }
  return(list(kap_post, H_post, acc_cnt));
}



test_vmf <-
function()
{
  kap_post <- list();
  num_obs <- 10;
  dims    <- c(4,3);
  num_iter = 20000;

  F       <- matrix(0, dims[1], dims[2]);
  diag(F) <- 1; #F[3,4] = 1;
  kap     <- diag(rexp(dims[2]));
  H       <- rmf.matrix(F);
  H_post  <- list();
  X       <- list();

  acc_cnt = 0;
  smpl <- list();
  for( iter in 1:num_iter ) {
    if (iter %% 50 == 0) {
      print(iter);
      print(kap);
      print(H);
      print(acc_cnt);
    }
    S = matrix(0, dims[1], dims[2]);
    for( p in 1:num_obs ) {
      X[[p]]  <- rmf.matrix(H %*% kap );
      S     <- S + X[[p]];
    }
#    smpl <- vmf_xchg(1, F, kap, H, num_obs, S, 0.3);
    smpl <- vmf_hmc(1, F, kap, H, num_obs, S, X, .3, 5);
#    smpl <- vmf_approx(1, F, kap, H, num_obs, S, 1);
    kap = smpl[[1]][[1]];
    H   = smpl[[2]][[1]];
    acc_cnt = acc_cnt + smpl[[3]][[1]];
    
    kap_post[[iter]] <- kap;
    H_post[[iter]]   <- H;
  }
  print(acc_cnt);

  # Need about 100K samples with 10 observations for this to work
  H_prior   <- list();
  for(iter in 1:num_iter ) {
    if (iter %% 500 == 0) {
      print(iter);
    }
    H_prior[[iter]] <- rmf.matrix(F); 
 }

  p_H = matrix(0,dims[1], dims[2]);
  for(i in 1:dims[1] ) {
    for(j in 1:dims[2] ) {
      x <- sapply(H_prior, function (x) x[i,j]);
      z <- sapply(H_post, function (x) x[i,j]);
      tmp <- ks.test(x,z)
      p_H[i,j] <- tmp[[2]]
    }
  }

  print(p_H);

  p_K <- matrix(0,1, dims[2]);
  thin = 30;
  for(i in 1:dims[2] ) {
    k <- sapply(kap_post, function (x) x[i,i]);
    z <- rexp(num_iter,1);
    tmp <- ks.test(k[seq(1,length(k),thin)],z[seq(1,length(z),thin)])
    p_K[i] <- tmp[[2]]
  }
  print(p_K);

  return(list(kap_post,k,z, H_post, p_H, H_prior));
}

plot_map <- function(X, dm, adj, col = 'red')
{
  library(maps);
  library(mapproj);

  plot.new()
  num_obs = length(X);

  lt_lg = matrix(0,num_obs,2);
  print(num_obs);

  for(i in 1:num_obs) {
    v          = X[[i]][,dm];
    lt_lg[i,1] = acos(v[3])*180/pi;
    lt_lg[i,2] = atan(v[2]/v[1])*180/pi;
  }
  m <- map(plot=FALSE);
  xy <- (mapproject(lt_lg[,1],lt_lg[,2],proj='azequalarea' ));
  col = matrix(43, num_obs);
  col[32:90] = 1;
  plot(xy, col = col)

  from_x = matrix(0, num_obs);
  from_y = matrix(0, num_obs);
  to_x = matrix(0, num_obs);
  to_y = matrix(0, num_obs);
  lwd  = matrix(0, num_obs);
  count = 1;
  diag(adj) = 0;
  adj[adj < 70] = 0;
  adj[adj > 80] = 80;
  q <- (max(adj));
  map.grid(m, nx=10, ny=10);
}


stuff <-
function() {
  set.seed(1);
  #source("rmf.matrix_prop.R")
  #load(file = "data_stief");
  #load(file = "two_data");
  # source("read_vcg.R")
  source("read_comets.R")

   num_iter = 50000;

   num_obs <- length(X);
   dims <- dim(X[[1]]);

    F       <- matrix(0, dims[1], dims[2]);
    diag(F) <- 1;
    kap     <- diag(1,dims[2]);
    H       <- rmf.matrix(F);

    S <- X[[1]];
    for( i in 2:num_obs ) {
      S <- S + X[[i]];
    }

  # smpl <- vmf_xchg(num_iter, F, kap, H, num_obs, S, 0.3);
  #  smpl <- vmf_xchg_approx(num_iter, F, kap, H, 10, S, 0.3, num_obs);
 # smpl <- vmf_hmc(num_iter, F, kap, H, num_obs, S, X, 0.3, 5);
 # smpl <- vmf_approx(num_iter, F, kap, H, num_obs, S, 0.3);

}
#  ret <- test_vmf();
