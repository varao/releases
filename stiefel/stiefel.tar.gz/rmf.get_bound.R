rmf.get_bound <-        
function(F, d)
{
  H <- F %*% diag(d)

  m<-dim(H)[1] ; R<-dim(H)[2]

  lr<-0

  for(j in seq(1,R,length=R))
  {
    if(d[j]>0)
    {
      xd<- sqrt(sum( H[,j]^2 ))
      lbr<-  log(besselI(xd, .5*(m-j-1),expon.scaled=TRUE))-
             .5*(m-j-1) * log(xd)

      if(is.na(lbr)){
        stop("NaN!");
        lbr<- .5*(log(xd) - log(xn)) 
      }

      lr<- lr+ lbr + lgamma(0.5*(m-j+1)) + .5*(m-j-1)*log(2)
    }
  }
  return(max(1,lr));
}

H = matrix(0,4,3)
diag(H) = 1;
svdH <- svd(H)

a <- rmf.get_bound(svdH$u, svdH$d)
print(a)

