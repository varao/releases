cmt  <- read.table("comets")  # Inclination (i), Argument of perihelion (w), Longitude of ascending node (N)
cmt  <- cmt*pi/180.0;

long <- (cmt[,2] + cmt[,3]) %% (2*pi);
lat  <- asin(sin(cmt[,2]) * sin(cmt[,3]));
N    <- cmt[,3];

tmp <- matrix(0,3,2);
X <- list();

for(i in 1:length(N)) {
  tmp[,1] <- c( cos(lat[i])*cos(long[i]), cos(lat[i])*sin(long[i]), sin(lat[i]) )
  tmp[,2] <- c( sin(lat[i])*sin(N[i]), -sin(lat[i])*cos(N[i]), -cos(lat[i])*sin(N[i]-long[i]) )
  tmp[,2] <- tmp[,2] / sqrt(sum(tmp[,2]^2));
  X[[i]] <- tmp;
}
