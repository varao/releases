# Vinayak Rao
# R code for inference on the stiefel manifold
#  Data augmentation for models based on rejection sampling 
#  Rao, V.A., Lin, L. and Dunson, D.B. (2014) 

library('coda');
source("vmf_inf.R");
source("rmf.matrix_prop.R")

if(1) {
  set.seed(2);
  #source("rmf.matrix_prop.R")
  #load(file = "data_stief");
  #load(file = "two_data");
  #source("read_vcg.R")
  source("read_comets.R")

   num_iter = 5000;

   num_obs <- length(X);
   dims <- dim(X[[1]]);

    F       <- matrix(0, dims[1], dims[2]);
#    diag(F) <- 1;
    kap     <- diag(2.5,dims[2]);
    H       <- rmf.matrix(F);

    S <- X[[1]];
    for( i in 2:num_obs ) {
      S <- S + X[[i]];
    }

  # smpl <- vmf_xchg(num_iter, F, kap, H, num_obs, S, 0.3);
  #  smpl <- vmf_xchg_approx(num_iter, F, kap, H, 10, S, 0.3, num_obs);
  #smpl <- vmf_hmc(num_iter, F, kap, H, num_obs, S, X, 0.2, 5);
  #smpl <- vmf_approx(num_iter, F, kap, H, num_obs, S, 0.3);

  max_num_cls = num_obs;
  n_c = matrix(0, max_num_cls, 1);
  kap_vec    <- list();
  kap_vec[[1]] <- kap;
  H_vec      <- list();
  H_vec[[1]]   <- H;


  n_c[1] = num_obs;
  c   = matrix(1, num_obs, 1);

  adj <- vmf_np(X, 1, F);
} else
{

  set.seed(2);

   source("read_vcg.R")
   num_obs <- length(X);
   num_iter = 5000;

    dims = c(3,2);
    F       <- matrix(0, dims[1], dims[2]);
#    diag(F) <- 1;
    kap     <- 5*diag(rgamma(dims[2],1));
    kap     <- diag(c(5,5));
    H       <- rmf.matrix(F);

#    X <- rmf.matrix_prop(F, kap);
#    print(X)
#    prj <- rmf.get_proj(F,X[[1]]);
#    print(prj)
     smpl <- vmf_hmc(num_iter, F, kap, H, num_obs, S, X, 0.2, 5, 10);
#    smpl <- vmf_approx(num_iter, F, kap, H, num_obs, S, 0.3,10);
}


  # smpl <- vmf_xchg(num_iter, F, kap, H, num_obs, S, 0.3);
  #  smpl <- vmf_xchg_approx(num_iter, F, kap, H, 10, S, 0.3, num_obs);
  #smpl <- vmf_hmc(num_iter, F, kap, H, num_obs, S, X, 0.2, 5);
