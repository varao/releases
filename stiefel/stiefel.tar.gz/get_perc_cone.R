
# if we haven't called gen_data_np, then set flag = 0

flag = 1;
if(flag == 0) {
  dirn <- list();
  for(i in 1:4000) {
    dirn[[i]] = smpl[[2]][[i]];
  }
}

d = 2;
vecs = matrix(0,3,4000);
S    = matrix(0, 3,1);
for(i in 1:4000) {
  v  = dirn[[i]][,d];
  v  = v / sqrt(sum(v*v));
  S        = S + v;
}
S = S/4000;

ip = matrix(0,1,4000);
for(i in 1:4000) {
  v  = dirn[[i]][,d];
  v  = v / sqrt(sum(v*v));
  ip[i] = t(S) %*% v;
}
q = quantile(ip,.1);
rad = tan(acos(q));
