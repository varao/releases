library("rstiefel");

num_obs = 1000;
F   <- list();
kap <- list();

F[[1]] = matrix( c( -0.01477467, -0.95505120, -0.29607249, -0.7227584, 0.2148146, -0.6568676), nrow = 3, ncol = 2);
F[[2]] = matrix( c( 0.2543669, 0.9469524,0.1964146, 0.4238698,-0.2917109,  0.8574609), nrow = 3, ncol = 2);
F[[3]] = matrix( c( 0.8669897, 0.3982286, -0.2995709, -0.3869651, 0.1592354, -0.9082412 ), nrow = 3, ncol = 2);

kap[[1]] = diag( c(12.5243, 11.13673));
kap[[2]] = diag( c(5.016428, 5.404733));
kap[[3]] = diag( c( 5.475255, 6.461525 ));
 

c = 2;
rad = c(0,0);

G = F[[c]] %*% kap[[c]];
dirn <- list();
for(i in 1:num_obs) {
  if((i %%50) == 0)
    print(i);
  dirn[[i]] <- rmf.matrix(G);
}

for(d in 1:2) {
  vecs = matrix(0,3,num_obs);
  S    = matrix(0, 3,1);
  for(i in 1:num_obs) {
    v  = dirn[[i]][,d];
    v  = v / sqrt(sum(v*v));
    S        = S + v;
  }
  S = S/num_obs;

  ip = matrix(0,1,num_obs);
  for(i in 1:num_obs) {
    v  = dirn[[i]][,d];
    v  = v / sqrt(sum(v*v));
    ip[i] = t(S) %*% v;
  }
  q = quantile(ip,.1);
  rad[d] = tan(acos(q));
}
