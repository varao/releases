load(file = "approx_err50.Res")

dim2 = c(3,4,5,8,10);

err1 <- matrix(0,3,5);
err2 <- matrix(0,3,5);

for( i in 1:5 ) {

  kp1      <- res[[i]][[1]][[4]];
  kp1_mean <- colMeans(kp1);

  kp2 <- res[[i]][[2]][[4]];
  kp2_mean <- colMeans(kp2);

  kp3 <- res[[i]][[3]][[4]];
  kp3_mean <- colMeans(kp3);

  err1[,i] <- kp2_mean - kp1_mean;
  err2[,i] <- kp3_mean - kp1_mean;
}

dim = 3;
llim = floor(min(err1[dim,], err2[dim,])); 
ulim = ceiling(max(err1[dim,], err2[dim,])); 
ulim = 2.5;

if(dim == 1) {
  pdf("approx_err1_50.pdf");
  y_str = expression(paste("Error in ",kappa[1])) 
} else if(dim == 2) {
  pdf("approx_err2_50.pdf");
  y_str = expression(paste("Error in ",kappa[2])) 
} else {
  pdf("approx_err3_50.pdf");
  y_str = expression(paste("Error in ",kappa[3])) }

mar.default <- c(5,5,4,2) + 0.1
par(mar = mar.default + c(0, 0.3, 0, 0)) 

plot(err1[dim,], type="o", pch=21, lty=1, col="blue", ylim = c(llim,ulim), xaxt = 'n', yaxt = 'n', ann = FALSE, lwd = 7)
lines(err2[dim,], type="o", pch=22, lty=2, col="red", lwd = 7)
axis(1, at=1:5, lab=c("3","4","5","8","10"),cex.axis = 2, cex.lab = 3)
axis(2, at=-1:4, lab=c("-1","0","1","2","3","4"),cex.axis = 2, cex.lab = 3)

title(ylab=y_str, col.lab=rgb(0,0.0,0), cex.lab = 3)
title(xlab="Ambient dimensionality", col.lab=rgb(0,0.0,0), cex.lab = 3)
#legend("topleft",c("HMC sampler", "Approximate sampler"), cex=3, col=c("blue","red"), pch=21:22, lty=1:2); 

dev.off();
